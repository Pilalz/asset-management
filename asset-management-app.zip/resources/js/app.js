import './bootstrap';

import jQuery from 'jquery';
window.$ = window.jQuery = jQuery;

import 'datatables.net-dt';

import 'flowbite';
import Alpine from 'alpinejs';

import ApexCharts from 'apexcharts';
window.ApexCharts = ApexCharts;

window.Alpine = Alpine;
Alpine.start();
